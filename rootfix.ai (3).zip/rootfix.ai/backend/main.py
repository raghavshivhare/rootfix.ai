from __future__ import annotations

import json
import os
import sqlite3
import uuid
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Literal

from dotenv import load_dotenv
from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, Field

BASE_DIR = Path(__file__).resolve().parent
load_dotenv(BASE_DIR / ".env")
DB_PATH = BASE_DIR / "self_healing.db"
GEMINI_API_KEY = os.getenv("GEMINI_API_KEY", "").strip()
GEMINI_MODEL = os.getenv("GEMINI_MODEL", "gemini-3.8-flash").strip()

app = FastAPI(
    title="Self-Healing AI Automation System API",
    version="1.0.0",
    description="Demo API for workflow monitoring, diagnosis, validated repair, and retry.",
)
app.add_middleware(
    CORSMiddleware,
    allow_origins=[
        "http://localhost:5173",
        "http://127.0.0.1:5173",
        "http://localhost:4173",
        "http://127.0.0.1:4173",
    ],
    allow_credentials=False,
    allow_methods=["*"],
    allow_headers=["*"],
)


def utc_now() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


def connect() -> sqlite3.Connection:
    con = sqlite3.connect(DB_PATH)
    con.row_factory = sqlite3.Row
    con.execute("PRAGMA foreign_keys = ON")
    return con


def as_dict(row: sqlite3.Row | None) -> dict[str, Any] | None:
    return dict(row) if row else None


def log_event(
    con: sqlite3.Connection,
    workflow_id: int | None,
    workflow_name: str,
    event_type: str,
    message: str,
    status: str = "info",
    details: dict[str, Any] | None = None,
) -> None:
    con.execute(
        """INSERT INTO events
        (workflow_id, workflow_name, event_type, message, status, details_json, timestamp)
        VALUES (?, ?, ?, ?, ?, ?, ?)""",
        (
            workflow_id,
            workflow_name,
            event_type,
            message,
            status,
            json.dumps(details or {}),
            utc_now(),
        ),
    )


def init_db() -> None:
    with connect() as con:
        con.executescript(
            """
            CREATE TABLE IF NOT EXISTS workflows (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                name TEXT NOT NULL,
                category TEXT NOT NULL,
                status TEXT NOT NULL DEFAULT 'Healthy',
                last_run TEXT NOT NULL,
                error_count INTEGER NOT NULL DEFAULT 0,
                latest_error TEXT NOT NULL DEFAULT ''
            );
            CREATE TABLE IF NOT EXISTS executions (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                run_id TEXT NOT NULL UNIQUE,
                workflow_id INTEGER NOT NULL,
                workflow_name TEXT NOT NULL,
                scenario TEXT NOT NULL,
                status TEXT NOT NULL,
                error_type TEXT NOT NULL,
                error_message TEXT NOT NULL,
                diagnosis TEXT NOT NULL,
                recommendation TEXT NOT NULL,
                original_payload TEXT NOT NULL,
                corrected_payload TEXT NOT NULL,
                validation_message TEXT NOT NULL DEFAULT '',
                attempts INTEGER NOT NULL DEFAULT 0,
                created_at TEXT NOT NULL,
                updated_at TEXT NOT NULL,
                FOREIGN KEY(workflow_id) REFERENCES workflows(id)
            );
            CREATE TABLE IF NOT EXISTS events (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                workflow_id INTEGER,
                workflow_name TEXT NOT NULL,
                event_type TEXT NOT NULL,
                message TEXT NOT NULL,
                status TEXT NOT NULL,
                details_json TEXT NOT NULL DEFAULT '{}',
                timestamp TEXT NOT NULL,
                FOREIGN KEY(workflow_id) REFERENCES workflows(id)
            );
            """
        )
        total = con.execute("SELECT COUNT(*) AS n FROM workflows").fetchone()["n"]
        if total == 0:
            now = utc_now()
            seed_workflows = [
                ("User Registration API", "API Integration", "Recovered", now, 2, "JSON schema mismatch"),
                ("Payment Processing", "Payments", "Healthy", now, 0, ""),
                ("Email Notification", "Notifications", "Failed", now, 1, "Invalid payload"),
                ("Data Synchronization", "Data Pipeline", "Healthy", now, 0, ""),
            ]
            con.executemany(
                "INSERT INTO workflows (name, category, status, last_run, error_count, latest_error) VALUES (?, ?, ?, ?, ?, ?)",
                seed_workflows,
            )
            ids = {r["name"]: r["id"] for r in con.execute("SELECT id, name FROM workflows").fetchall()}
            log_event(con, ids["User Registration API"], "User Registration API", "Recovery", "Previous schema mismatch corrected and validated.", "success")
            log_event(con, ids["Payment Processing"], "Payment Processing", "Execution", "Health check completed successfully.", "success")
            log_event(con, ids["Email Notification"], "Email Notification", "Failure", "Invalid payload detected during notification request.", "error")
            log_event(con, ids["Data Synchronization"], "Data Synchronization", "Execution", "Synchronization completed successfully.", "success")


@app.on_event("startup")
def startup() -> None:
    init_db()


class SimulateRequest(BaseModel):
    scenario: Literal["schema_mismatch", "missing_field", "temporary_error"] = "schema_mismatch"


class Diagnosis(BaseModel):
    error_type: str
    diagnosis: str
    recommendation: str


def deterministic_diagnosis(scenario: str) -> Diagnosis:
    if scenario == "schema_mismatch":
        return Diagnosis(
            error_type="JSON Schema Mismatch",
            diagnosis="The receiving API expects the keys 'id', 'name', and 'email', but the workflow sent 'user_id', 'user_name', and 'email_address'.",
            recommendation="Transform the payload using the receiving API's known schema, validate all required fields, then retry.",
        )
    if scenario == "missing_field":
        return Diagnosis(
            error_type="Missing Required Field",
            diagnosis="The request does not contain the required 'email' field. The missing value cannot be safely inferred from the remaining payload.",
            recommendation="Pause automated repair and request the missing value or route the event to a human for review.",
        )
    return Diagnosis(
        error_type="Temporary Service Failure",
        diagnosis="The mock downstream service returned a temporary 503-style service-unavailable response.",
        recommendation="Use a bounded retry with exponential backoff. Do not change the request payload for a transient service error.",
    )


def maybe_ai_diagnosis(scenario: str, payload: dict[str, Any], fallback: Diagnosis) -> Diagnosis:
    """Optional Gemini diagnosis. Rule-based fallback keeps the demo usable without a key."""
    if not GEMINI_API_KEY:
        return fallback
    try:
        from google import genai
        from google.genai import types

        client = genai.Client(api_key=GEMINI_API_KEY)
        prompt = f"""You are a cautious workflow incident analyst. Diagnose this simulated workflow failure.
Return only JSON with string properties: error_type, diagnosis, recommendation.
Do not invent missing customer data. Do not claim a fix was executed. Do not recommend bypassing validation.
Scenario: {scenario}
Payload: {json.dumps(payload)}
Rule-based initial diagnosis: {fallback.model_dump_json()}
Keep diagnosis and recommendation concise and actionable."""
        response = client.models.generate_content(
            model=GEMINI_MODEL,
            contents=prompt,
            config=types.GenerateContentConfig(response_mime_type="application/json"),
        )
        data = json.loads(response.text or "{}")
        return Diagnosis(
            error_type=str(data.get("error_type") or fallback.error_type)[:120],
            diagnosis=str(data.get("diagnosis") or fallback.diagnosis)[:700],
            recommendation=str(data.get("recommendation") or fallback.recommendation)[:700],
        )
    except Exception:
        # A model/API failure must not break incident recording or the demo.
        return fallback


def payloads_for(scenario: str) -> tuple[dict[str, Any], dict[str, Any]]:
    if scenario == "schema_mismatch":
        original = {
            "user_id": 101,
            "user_name": "Jainam",
            "email_address": "jainam@example.com",
        }
        corrected = {"id": original["user_id"], "name": original["user_name"], "email": original["email_address"]}
        return original, corrected
    if scenario == "missing_field":
        original = {"id": 202, "name": "Aarav"}
        # Deliberately do not fabricate a corrected payload for missing user data.
        return original, original
    original = {"id": 303, "name": "Payment Sync", "amount": 499.0, "currency": "INR"}
    return original, original


def read_execution(con: sqlite3.Connection, execution_id: int) -> dict[str, Any] | None:
    row = con.execute("SELECT * FROM executions WHERE id = ?", (execution_id,)).fetchone()
    if not row:
        return None
    result = dict(row)
    for key in ("original_payload", "corrected_payload"):
        try:
            result[key] = json.loads(result[key])
        except (TypeError, json.JSONDecodeError):
            result[key] = {}
    return result


@app.get("/api/health")
def health() -> dict[str, Any]:
    return {"status": "ok", "service": "self-healing-api", "ai_configured": bool(GEMINI_API_KEY), "ai_model": GEMINI_MODEL if GEMINI_API_KEY else None, "time": utc_now()}


@app.get("/api/dashboard")
def dashboard() -> dict[str, Any]:
    with connect() as con:
        workflows = con.execute("SELECT * FROM workflows ORDER BY id").fetchall()
        executions = con.execute("SELECT status FROM executions").fetchall()
        total = len(workflows)
        failed = sum(1 for w in workflows if w["status"] in ("Failed", "Investigating", "Awaiting Approval", "Needs Review", "Retry Recommended"))
        recovered = sum(1 for w in workflows if w["status"] == "Recovered")
        attempts = len(executions)
        successful = sum(1 for e in executions if e["status"] == "Recovered")
        historical_recoveries = con.execute("SELECT COUNT(*) AS n FROM events WHERE event_type = 'Recovery' AND status = 'success'").fetchone()["n"]
        # The seeded historical recovery is included as a demo event, rather than double-counting workflow status.
        rate = round((successful + historical_recoveries) / max(attempts + 1, 1) * 100)
        return {
            "total_workflows": total,
            "failed_executions": failed,
            "successfully_recovered": historical_recoveries + successful,
            "recovery_success_rate": rate,
            "ai_enabled": bool(GEMINI_API_KEY),
            "workflows": [dict(w) for w in workflows],
        }


@app.get("/api/workflows")
def list_workflows() -> list[dict[str, Any]]:
    with connect() as con:
        return [dict(row) for row in con.execute("SELECT * FROM workflows ORDER BY id").fetchall()]


@app.get("/api/executions")
def list_executions(limit: int = 20) -> list[dict[str, Any]]:
    limit = max(1, min(limit, 100))
    with connect() as con:
        rows = con.execute("SELECT * FROM executions ORDER BY id DESC LIMIT ?", (limit,)).fetchall()
        return [read_execution(con, int(row["id"])) for row in rows]


@app.get("/api/executions/{execution_id}")
def get_execution(execution_id: int) -> dict[str, Any]:
    with connect() as con:
        execution = read_execution(con, execution_id)
        if not execution:
            raise HTTPException(status_code=404, detail="Execution not found")
        return execution


@app.get("/api/logs")
def list_logs(limit: int = 80) -> list[dict[str, Any]]:
    limit = max(1, min(limit, 200))
    with connect() as con:
        rows = con.execute("SELECT * FROM events ORDER BY id DESC LIMIT ?", (limit,)).fetchall()
        items = []
        for row in rows:
            item = dict(row)
            try:
                item["details"] = json.loads(item.pop("details_json"))
            except json.JSONDecodeError:
                item["details"] = {}
            items.append(item)
        return items


@app.post("/api/simulate")
def simulate_failure(request: SimulateRequest) -> dict[str, Any]:
    scenario = request.scenario
    original, corrected = payloads_for(scenario)
    base_diagnosis = deterministic_diagnosis(scenario)
    diagnosis = maybe_ai_diagnosis(scenario, original, base_diagnosis)
    error_message = {
        "schema_mismatch": "422 Unprocessable Entity: payload fields do not match the expected schema",
        "missing_field": "422 Unprocessable Entity: required field 'email' is missing",
        "temporary_error": "503 Service Unavailable: downstream service temporarily unavailable",
    }[scenario]
    workflow_name = {
        "schema_mismatch": "User Registration API",
        "missing_field": "Email Notification",
        "temporary_error": "Data Synchronization",
    }[scenario]
    with connect() as con:
        workflow = con.execute("SELECT * FROM workflows WHERE name = ?", (workflow_name,)).fetchone()
        if not workflow:
            cur = con.execute(
                "INSERT INTO workflows (name, category, status, last_run, error_count, latest_error) VALUES (?, ?, ?, ?, ?, ?)",
                (workflow_name, "API Integration", "Failed", utc_now(), 1, diagnosis.error_type),
            )
            workflow_id = int(cur.lastrowid)
        else:
            workflow_id = int(workflow["id"])
            workflow_status = {"schema_mismatch": "Awaiting Approval", "missing_field": "Needs Review", "temporary_error": "Retry Recommended"}[scenario]
            con.execute(
                "UPDATE workflows SET status = ?, last_run = ?, error_count = error_count + 1, latest_error = ? WHERE id = ?",
                (workflow_status, utc_now(), diagnosis.error_type, workflow_id),
            )
        now = utc_now()
        run_id = f"SH-{uuid.uuid4().hex[:8].upper()}"
        status = "Awaiting Approval" if scenario == "schema_mismatch" else "Needs Review" if scenario == "missing_field" else "Retry Recommended"
        cur = con.execute(
            """INSERT INTO executions
            (run_id, workflow_id, workflow_name, scenario, status, error_type, error_message, diagnosis, recommendation,
             original_payload, corrected_payload, validation_message, attempts, created_at, updated_at)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
            (run_id, workflow_id, workflow_name, scenario, status, diagnosis.error_type, error_message,
             diagnosis.diagnosis, diagnosis.recommendation, json.dumps(original), json.dumps(corrected),
             "Not yet validated", 0, now, now),
        )
        execution_id = int(cur.lastrowid)
        log_event(con, workflow_id, workflow_name, "Failure Detected", error_message, "error", {"run_id": run_id, "scenario": scenario})
        log_event(con, workflow_id, workflow_name, "AI Diagnosis", diagnosis.diagnosis, "warning", {"run_id": run_id, "recommendation": diagnosis.recommendation})
        if scenario == "schema_mismatch":
            log_event(con, workflow_id, workflow_name, "Fix Generated", "Proposed field mapping generated; awaiting validation and human approval.", "info", {"run_id": run_id})
        elif scenario == "missing_field":
            log_event(con, workflow_id, workflow_name, "Human Review Required", "The system will not invent a missing email address.", "warning", {"run_id": run_id})
        else:
            log_event(con, workflow_id, workflow_name, "Retry Recommended", "A bounded retry is recommended for this temporary error.", "info", {"run_id": run_id})
        execution = read_execution(con, execution_id)
        return {"execution": execution, "message": "Failure simulated and diagnosis recorded."}


@app.post("/api/executions/{execution_id}/approve")
def approve_and_execute(execution_id: int) -> dict[str, Any]:
    with connect() as con:
        execution = read_execution(con, execution_id)
        if not execution:
            raise HTTPException(status_code=404, detail="Execution not found")
        if execution["status"] == "Recovered":
            return {"execution": execution, "message": "This execution has already been recovered."}
        if execution["status"] == "Fix Rejected":
            raise HTTPException(status_code=400, detail="This proposed fix was rejected and cannot be executed. Create a new run to reconsider it.")
        if execution["scenario"] != "schema_mismatch":
            raise HTTPException(status_code=400, detail="This scenario cannot be auto-repaired safely. Use manual review or retry.")
        corrected = execution["corrected_payload"]
        # Deterministic validation against the receiving service's required schema.
        required = {"id", "name", "email"}
        if not isinstance(corrected, dict) or not required.issubset(corrected.keys()) or not all(corrected[k] for k in required):
            con.execute("UPDATE executions SET status = 'Validation Failed', validation_message = ?, updated_at = ? WHERE id = ?", ("Corrected payload failed schema validation.", utc_now(), execution_id))
            raise HTTPException(status_code=422, detail="Corrected payload failed schema validation")
        con.execute(
            "UPDATE executions SET status = 'Recovered', validation_message = ?, attempts = attempts + 1, updated_at = ? WHERE id = ?",
            ("PASS — id, name, and email are present and non-empty.", utc_now(), execution_id),
        )
        con.execute(
            "UPDATE workflows SET status = 'Recovered', last_run = ?, latest_error = '' WHERE id = ?",
            (utc_now(), execution["workflow_id"]),
        )
        log_event(con, execution["workflow_id"], execution["workflow_name"], "Validation", "Corrected payload passed schema validation.", "success", {"run_id": execution["run_id"], "payload": corrected})
        log_event(con, execution["workflow_id"], execution["workflow_name"], "Retry Executed", "Mock downstream API accepted the corrected payload. Recovery successful.", "success", {"run_id": execution["run_id"]})
        return {"execution": read_execution(con, execution_id), "message": "Fix validated; mock API accepted the corrected payload."}


@app.post("/api/executions/{execution_id}/reject")
def reject_fix(execution_id: int) -> dict[str, Any]:
    with connect() as con:
        execution = read_execution(con, execution_id)
        if not execution:
            raise HTTPException(status_code=404, detail="Execution not found")
        con.execute("UPDATE executions SET status = 'Fix Rejected', updated_at = ? WHERE id = ?", (utc_now(), execution_id))
        con.execute("UPDATE workflows SET status = 'Failed', last_run = ? WHERE id = ?", (utc_now(), execution["workflow_id"]))
        log_event(con, execution["workflow_id"], execution["workflow_name"], "Fix Rejected", "Proposed correction was rejected by the reviewer. No retry was executed.", "warning", {"run_id": execution["run_id"]})
        return {"execution": read_execution(con, execution_id), "message": "Fix rejected. No retry was performed."}


@app.post("/api/executions/{execution_id}/retry")
def retry_manually(execution_id: int) -> dict[str, Any]:
    with connect() as con:
        execution = read_execution(con, execution_id)
        if not execution:
            raise HTTPException(status_code=404, detail="Execution not found")
        attempts = int(execution["attempts"]) + 1
        if execution["scenario"] == "temporary_error" and attempts <= 2:
            status = "Recovered"
            message = "Temporary error cleared in the mock service; retry succeeded."
            log_status = "success"
            workflow_status = "Recovered"
        else:
            status = "Failed"
            message = "Retry used the original request and failed. Review the diagnosis or approve a validated fix."
            log_status = "error"
            workflow_status = "Failed"
        con.execute("UPDATE executions SET status = ?, attempts = ?, updated_at = ? WHERE id = ?", (status, attempts, utc_now(), execution_id))
        con.execute("UPDATE workflows SET status = ?, last_run = ? WHERE id = ?", (workflow_status, utc_now(), execution["workflow_id"]))
        log_event(con, execution["workflow_id"], execution["workflow_name"], "Manual Retry", message, log_status, {"run_id": execution["run_id"], "attempt": attempts})
        return {"execution": read_execution(con, execution_id), "message": message}
